# Lab Professor: Maziar Sojoudian
# Final Project
# Student: Nelson Ortiz (101313314)

import sys
import random
import string
import json
from decimal import Decimal
import sqlite3

# ----------------------- Helper Functions ------------------------------------------------------


# get valid input
def get_valid_input(prompt_message):
    while True:
        user_input = input(prompt_message)
        if user_input:
            return user_input
        print("Input cannot be empty. Please try again.")


# get valid type
def get_valid_type(prompt_message, types):
    while True:
        user_input = input(prompt_message)
        if user_input and user_input in types:
            return user_input
        print("Please enter one of the following values: " + ', '.join(types))


# get valid number
def get_valid_number(prompt_message):
    while True:
        user_input = input(prompt_message)
        try:
            number = float(user_input)
            if number >= 0:
                return number
            else:
                print("Please enter a valid positive number...")
        except ValueError:
            print("Please enter a valid number...")


def get_valid_month(prompt_message):
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    while True:
        user_input = input(prompt_message)
        if user_input and user_input in months:
            return user_input
        print("Please enter a valid month...")


def get_valid_day(prompt_message):
    while True:
        user_input = input(prompt_message)
        if user_input and int(user_input) <= 31:
            return user_input
        print("Please enter a valid day...")


#  ----------------------- User Entry --------------------------------------------
def username():
    user_name = get_valid_input("Please enter your username: ")
    try:
        conn = sqlite3.connect('expenses.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM expenses WHERE username = ?", (user_name,))
        count = cursor.fetchone()[0]
        if count == 0:
            print(f"There is no data for the username '{user_name}'. Welcome, {user_name}!")
        else:
            print(f"Welcome back, {user_name}!!")
        return user_name
    except sqlite3.Error as e:
        print("Error accessing database:", e)
    finally:
        conn.close()


#  ----------------------- Entering Expenses --------------------------------------------
class ExpenseTracker:
    def __init__(self, username):
        self.username = username
        self.conn = sqlite3.connect('expenses.db')
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS expenses (
                                            id INTEGER PRIMARY KEY,
                                            username TEXT NOT NULL,
                                            category TEXT NOT NULL,
                                            amount REAL NOT NULL,
                                            year INTEGER NOT NULL,
                                            month TEXT NOT NULL,
                                            day INTEGER NOT NULL
                                          )''')
        self.conn.commit()

    # def add_expense(self):
    #     amount = float(get_valid_number("Please enter the amount: "))
    #     category = get_valid_type("Please choose the expense category: (Food, Rent, Utilities, Clothing, Entertainment, Internet, Others) ", ['Food', 'Rent', 'Utilities', 'Clothing', 'Entertainment', 'Internet'])
    #     year = get_valid_number("Year of the expense: ")
    #     month = get_valid_month("Month of the expense: ")
    #     day = get_valid_day("Day of the expense: ")
    #     self.expenses.append({"Category": category, "Amount": amount, "Year": year, "Month": month, "Day": day})

    def add_expense(self, category, amount, year, month, day):
        self.cursor.execute('''INSERT INTO expenses (username, category, amount, year, month, day) 
                               VALUES (?, ?, ?, ?, ?, ?)''', (self.username, category, amount, year, month, day))
        self.conn.commit()

    def save_to_file(self, category, amount, year, month, day):
        try:
            self.add_expense(category, amount, year, month, day)
            self.conn.commit()
            print("Expenses saved to database successfully.")
        except sqlite3.Error as e:
            print("Error saving expenses to database:", e)

    def load_from_file(self):
        try:
            self.cursor.execute('''SELECT * FROM expenses WHERE username=?''', (self.username,))
            self.expenses = self.cursor.fetchall()
            print("Expenses loaded from database successfully.")
        except sqlite3.Error as e:
            print("Error loading expenses from database:", e)
            self.expenses = []

    # def get_expenses_by_month_year(self, month, year):
    #     expenses_list = self.expenses
    #     expenses_list_month_year = []
    #     for expense in expenses_list:
    #         if expense["Month"] == month and expense["Year"] == year:
    #             expenses_list_month_year.append(expense)
    #     return expenses_list_month_year
    def get_expenses_by_month_year(self, month, year):
        self.cursor.execute('''SELECT * FROM expenses 
                               WHERE username=? AND month=? AND year=?''', (self.username, month, year))
        return self.cursor.fetchall()

    # def get_yearly_average_by_category(self, year):
    #     category_totals = {}
    #     category_counts = {}
    #
    #     # Initialize category totals and counts
    #     for expense in self.expenses:
    #         category = expense["Category"]
    #         amount = expense["Amount"]
    #         if expense["Year"] == year:
    #             category_totals[category] = category_totals.get(category, 0) + amount
    #             category_counts[category] = category_counts.get(category, 0) + 1
    #
    #     # Calculate yearly average for each category
    #     yearly_averages = {}
    #     for category, total in category_totals.items():
    #         count = category_counts[category]
    #         yearly_averages[category] = total / count
    #
    #     return yearly_averages
    def get_yearly_average_by_category(self, year):
        self.cursor.execute('''SELECT category, AVG(amount) AS average FROM expenses 
                               WHERE username=? AND year=? 
                               GROUP BY category''', (self.username, year))
        return {row[0]: row[1] for row in self.cursor.fetchall()}

    def close_connection(self):
        self.conn.close()


#  ----------------------- Entering Expenses --------------------------------------------
def enter_expenses():
    while True:
        amount = float(get_valid_number("Please enter the amount: "))
        category = get_valid_type(
            "Please choose the expense category: (Food, Rent, Utilities, Clothing, Entertainment, Internet, Others) ",
            ['Food', 'Rent', 'Utilities', 'Clothing', 'Entertainment', 'Internet', 'Others'])
        year = get_valid_number("Year of the expense: ")
        month = get_valid_month("Month of the expense: ")
        day = get_valid_day("Day of the expense: ")

        current_user_expenses.save_to_file(category, amount, year, month, day)

        user_input = get_valid_type("Would you like to repeat the process? (Y/N) ", ['Y', 'y', 'N', 'n'])
        if user_input and user_input in ['N', 'n']:
            break
        elif user_input and user_input not in ['Y', 'y']:
            print("Please enter a valid answer...")


#  ----------------------- Show Monthly Report --------------------------------------------
def show_report(user_month, user_year):
    monthly_list = current_user_expenses.get_expenses_by_month_year(user_month, user_year)
    total_monthly_expenses = sum(expense[3] for expense in monthly_list)

    print(f"| {'Year': ^6} | {'Month': ^12} | {'Day': ^8} | {'Category': ^20} | ${'Amount': ^8} |")
    for expense in monthly_list:
        print(f"| {expense[4]: ^6} | {expense[5]: ^12} | {expense[6]: ^8} | {expense[2]: <20} | ${expense[3]: >8.2f} |")

    print(f"Total Monthly Expenses: ${total_monthly_expenses}")

    yearly_averages = current_user_expenses.get_yearly_average_by_category(user_year)
    print("Yearly Averages for Each Category:")
    for category, average in yearly_averages.items():
        print(f"{category}: ${average:.2f}")

        print("\nComparison of Monthly Expenses with Annual Averages:")
        print(f"| {'Category': ^20} | {'Monthly %': ^10} | {'Annual Average': ^14} | {'Comparison': ^12} |")
        for expense in monthly_list:
            category = expense[2]
            amount = expense[3]
            annual_average = yearly_averages.get(category, 0)
            monthly_percentage = (amount / total_monthly_expenses) * 100
            comparison = "Higher" if amount > annual_average else "Lower"
            print(
                f"| {category: <20} | {monthly_percentage: >10.2f}% | ${annual_average: >13.2f} | {comparison: ^12} |")

        return yearly_averages

# ----------------------- Main Menu -----------------------------------------------------
def clear_database():
    conn = sqlite3.connect('expenses.db')
    cursor = conn.cursor()

    try:
        cursor.execute('DELETE FROM expenses')
        conn.commit()
        print("All data deleted successfully.")
    except sqlite3.Error as e:
        print("Error deleting data:", e)
    finally:
        conn.close()


# ----------------------- Main Menu -----------------------------------------------------
def main_menu():
    choice = 0
    while choice != 5:
        print("==================================================================================")
        print("|                                    Main Menu                                   |")
        print("==================================================================================")
        print("|             1) Enter Expenses                                                  |")
        print("|             2) Show Monthly Expense Report                                     |")
        print("|             3) Edit Expenses?                                                  |")
        print("|             4) Clear Database                                                  |")
        print("|             5) Exit                                                            |")
        print("==================================================================================")

        try:
            choice = int(input("Please enter your choice: "))
            if choice < 1 or choice > 5:
                raise ValueError("Invalid choice. Please select a number between 1 and 4.")
        except ValueError as ve:
            print(ve)
        except Exception as e:
            print("An unexpected error occurred:", e)

        if choice == 1:
            print("Entering Expenses...")
            enter_expenses()
        elif choice == 2:
            user_month = get_valid_month("Month of the report: ")
            user_year = get_valid_number("Year of the report: ")
            if user_year < 1900 or user_year > 2100:  # Validating year range
                print("Invalid year. Please enter a year between 1900 and 2100.")
                continue
            print("Showing Monthly Report...")
            show_report(user_month, user_year)
            yearly_averages = current_user_expenses.get_yearly_average_by_category(user_year)
            print("\nYearly Averages for Each Category:")
            for category, average in yearly_averages.items():
                print(f"{category}: ${average:.2f}")
        elif choice == 3:
            print("Editing Expenses...")
            # edit_expenses()
        elif choice == 4:
            clear_database()
        elif choice == 5:
            print("Exiting...")
            current_user_expenses.close_connection()
            sys.exit()
        else:
            print("Invalid choice. Please select a number between 1 and 4.")


# ----------------------- Run -----------------------------------------------------
print("==================================================================================")
print("Welcome to the Final Project: Expense Tracker")
print("==================================================================================")
try:
    current_username = username()
    current_user_expenses = ExpenseTracker(current_username)
    current_user_expenses.load_from_file()
    main_menu()
except Exception as e:
    print("An error occurred:", e)